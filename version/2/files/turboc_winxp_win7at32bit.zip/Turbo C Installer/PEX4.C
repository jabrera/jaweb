#include<stdio.h>
main()
{
char fname[20];
char lname[20];
float a, sq, lq, sw, hw, pe, pg;
clrscr();
printf("\t\t          ITCS111L - Computer Programming 1\n");
printf("                               Enter First Name:");
scanf("%s",&fname);
printf("                               Enter Last Name:");
scanf("%s",&lname);
printf("Attendance:\t\t");
scanf("%f",&a);
a=a/100*0.10;
printf("        SQ:\t\t");
scanf("%f",&sq);
sq=sq/100*0.15;
printf("        LQ:\t\t");
scanf("%f",&lq);
lq=lq/100*0.20;
printf("        SW:\t\t");
scanf("%f",&sw);
sw=sw/100*0.15;
printf("       ASS:\t\t");
scanf("%f",&hw);
hw=hw/100*0.10;
printf("PrelimExam:\t\t");
scanf("%f",&pe);
pe=pe/100*0.30;
pg=(a+sq+lq+sw+hw+pe)*100;
printf("\n\n\nProgrammed by: %s %s\n Prelim Grade is %f over 100", fname, lname, pg);
getche();
}